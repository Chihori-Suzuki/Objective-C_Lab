//
//  main.m
//  Lab2
//
//  Created by Derrick Park on 2021-02-22.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
  @autoreleasepool {
      // insert code here...
      NSLog(@"Hello, World!");
  }
  return 0;
}
